# Mshpy

The Mshpy module provides simplified magnetosheath model.
See
* Full [documentation](https://mshpy.readthedocs.io/en/latest/)

# Installation

Installation is avaliable through pypi

```
    $ pip install Mshpy
```

# Example
Example is available in the documentation.
